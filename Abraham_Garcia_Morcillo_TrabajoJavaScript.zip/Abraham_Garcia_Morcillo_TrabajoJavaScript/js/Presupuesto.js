// Presupuesto.js

function calcularPresupuesto() {
    var espadaSelect = document.getElementById("Espadas");
    var selectedEspadaOption = espadaSelect.options[espadaSelect.selectedIndex];
    
    if (selectedEspadaOption.value === "") {
        // No se ha seleccionado ningún producto
        document.getElementById("descuento").innerHTML = "";
        document.getElementById("presupuesto").innerHTML = "Seleccione un producto para ver el presupuesto.";
        return;
    }
    
    var precio = parseInt(selectedEspadaOption.getAttribute("data-precio"));
    var descuento = 0;
    var precioFinal = precio;

    // Obtén los días de descuento y el descuento asociado
    var diasDescuentoSelect = document.getElementById("diasConDescuento");
    var selectedDescuentoOption = diasDescuentoSelect.options[diasDescuentoSelect.selectedIndex];

    if (selectedDescuentoOption && selectedDescuentoOption.value !== "") {
        descuento = parseInt(selectedDescuentoOption.getAttribute("data-descuento"));
        precioFinal -= precioFinal * (descuento / 100);
    }

    if (document.getElementById("extra1").checked) {
        precioFinal += 10;
    }

    if (document.getElementById("extra2").checked) {
        precioFinal += 20;
    }

    if (document.getElementById("extra3").checked) {
        precioFinal += 30;
    }

    document.getElementById("descuento").innerHTML = "Descuento aplicado: " + descuento + "%";
    document.getElementById("presupuesto").innerHTML = "Presupuesto: $" + precioFinal.toFixed(2);
}

function enviarFormulario() {
    var aceptarCondiciones = document.getElementById("aceptarCondiciones").checked;

    if (!aceptarCondiciones) {
        alert("Debes aceptar las condiciones de privacidad para enviar el formulario.");
        return;
    }

    alert("Formulario enviado correctamente.");
}

function validarFormulario() {
    var nombre = document.getElementById("nombre").value;
    var apellidos = document.getElementById("apellidos").value;
    var telefono = document.getElementById("Numero_1").value;
    var correo = document.getElementById("Correo_2").value;

    var nombreRegex = /^[a-zA-Z\s]+$/;
    var apellidosRegex = /^[a-zA-Z\s]+$/;
    var telefonoRegex = /^[0-9]{9}$/;
    var correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!nombre.match(nombreRegex)) {
        alert("Por favor, introduce un nombre válido (solo letras y espacios).");
        return false;
    }

    if (!apellidos.match(apellidosRegex)) {
        alert("Por favor, introduce unos apellidos válidos (solo letras y espacios).");
        return false;
    }

    if (!telefono.match(telefonoRegex)) {
        alert("Por favor, introduce un número de teléfono válido (9 dígitos).");
        return false;
    }

    if (!correo.match(correoRegex)) {
        alert("Por favor, introduce un correo electrónico válido.");
        return false;
    }

    alert("¡Formulario enviado con éxito!");
    return true;
}
