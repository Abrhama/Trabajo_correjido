
const espadas = [
    {
        "nombre": "Katana",
        "origen": "Japón",
        "longitud": 70,
        "peso": 1.2,
        "material": "acero",
        "descripción": "Una espada japonesa tradicional con una hoja curva y afilada."
    },
    {
        "nombre": "Espada Larga",
        "origen": "Europa",
        "longitud": 110,
        "peso": 1.5,
        "material": "acero",
        "descripción": "Una espada utilizada en la Edad Media y Renacimiento, caracterizada por su longitud y versatilidad en combate."
    },
    {
        "nombre": "Scimitar",
        "origen": "Medio Oriente",
        "longitud": 80,
        "peso": 1.3,
        "material": "acero",
        "descripción": "Una espada de hoja curva y ancha, utilizada principalmente por los pueblos árabes y persas."
    },
    {
        "nombre": "Gladius",
        "origen": "Roma",
        "longitud": 60,
        "peso": 0.8,
        "material": "acero",
        "descripción": "La espada corta utilizada por los soldados romanos, eficaz en el combate cuerpo a cuerpo."
    },
    {
        "nombre": "Espada Vikinga",
        "origen": "Escandinavia",
        "longitud": 90,
        "peso": 1.4,
        "material": "acero",
        "descripción": "Una espada con una hoja ancha y doble filo, utilizada por los vikingos durante sus incursiones."
    }
];

function mostrarEspadas() {
    const container = document.getElementById('espadas-container');
    espadas.forEach(espada => {
        const espadaDiv = document.createElement('div');
        espadaDiv.classList.add('espada');

        espadaDiv.innerHTML = `
            <h2>${espada.nombre}</h2>
            <p><strong>Origen:</strong> ${espada.origen}</p>
            <p><strong>Longitud:</strong> ${espada.longitud} cm</p>
            <p><strong>Peso:</strong> ${espada.peso} kg</p>
            <p><strong>Material:</strong> ${espada.material}</p>
            <p><strong>Descripción:</strong> ${espada.descripción}</p>
        `;

        container.appendChild(espadaDiv);
    });
}

window.onload = mostrarEspadas;
