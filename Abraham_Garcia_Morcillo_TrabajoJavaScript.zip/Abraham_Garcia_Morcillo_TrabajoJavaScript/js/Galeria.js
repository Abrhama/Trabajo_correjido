

const images = [
    "https://www.eliteguias.com/img/juegos/elden-ring/espada-del-ejecutor-marais.jpg",
    "https://www.eliteguias.com/img/juegos/elden-ring/espada-curva-de-dios-serpiente.jpg",
    "https://www.eliteguias.com/img/juegos/elden-ring/espada-de-santa-trina.jpg"
]; 

const thumbnailsContainer = document.getElementById("thumbnails");
const previewImage = document.getElementById("preview");

images.forEach(image => {
    const thumbnail = document.createElement("img");
    thumbnail.src = image;
    thumbnail.classList.add("thumbnail");
    thumbnail.addEventListener("click", () => {
        previewImage.src = image;
    });
    thumbnailsContainer.appendChild(thumbnail);
});

previewImage.src = images[0];

